
#include "trace_generator.hpp"

#include <cstdint>
#include <cstddef>
#include <stdexcept>
#include <algorithm>
#include <string>
#include <vector>

// ============================================================
// OPERATION CREATION
// ============================================================

InSramOp make_op(
    uint64_t id,
    OpType type,
    int src1,
    int src2,
    int dest,
    bool load1,
    bool load2,
    bool calc,
    bool store,
    bool branch
) {
    InSramOp op{};

    op.op_id = id;

    op.warp_id = 0;
    op.subarray_id = 0;

    op.type = type;

    op.src1 = src1;
    op.src2 = src2;
    op.dest = dest;

    op.has_imm = false;
    op.imm_val = 0;

    // Independent operation phases
    op.has_load1 = load1;
    op.has_load2 = load2;
    op.has_calc = calc;
    op.has_store = store;

    op.affects_control_flow = branch;

    // PipeIMC memory-phase step latencies
    op.addr_cycles = 2;
    op.visit_cycles = 16;
    op.writeback_cycles = 2;

    // PipeIMC Table III calculation latencies
    switch (type) {

        case OpType::ADD:
        case OpType::LOGIC:
            op.calc_cycles = 9;
            break;

        case OpType::SUB:
            op.calc_cycles = 17;
            break;

        case OpType::MUL:
            // Minimum multiplication latency.
            // Actual latency depends on operand width.
            op.calc_cycles = 105;
            break;

        case OpType::DIV:
            // Minimum division latency.
            // Actual latency depends on operand width.
            op.calc_cycles = 145;
            break;

        case OpType::BRANCH:
            // Simplified branch-resolution latency.
            // This is a simulator assumption, not a
            // calculation latency specified in Table III.
            op.calc_cycles = 13;
            break;

        case OpType::BARRIER:
            // Simplified synchronization latency.
            op.calc_cycles = 1;
            break;
    }

    return op;
}

// ============================================================
// INPUT VALIDATION
// ============================================================

// deterministic small test values
static int32_t pat(int k, int mul, int add, int mod, int off) {
    return (k * mul + add) % mod - off;
}

static std::string list_values(const std::vector<int32_t>& m, const char* name,
                               const std::vector<uint32_t>& addr) {
    std::string s = std::string(name) + " =";
    size_t shown = std::min<size_t>(addr.size(), 16);
    for (size_t i = 0; i < shown; ++i) s += " " + std::to_string(m[addr[i]]);
    if (shown < addr.size()) s += " ...";
    return s;
}

static void validate_iterations(int iterations) {

    if (iterations <= 0) {
        throw std::invalid_argument(
            "Number of iterations must be greater than zero."
        );
    }
}

// ============================================================
// 1. MATRIX MULTIPLICATION
// ============================================================
//
// Simplified inner-product operation trace.
//
// O1: Load A1 and B1; calculate A1 * B1.
// O2: Load A2 and B2; calculate A2 * B2.
// O3: Add the two multiplication results.
// O4: Accumulate the partial result and store output.
// B : Loop-control branch.
//
// Five operations per iteration.
//
// ============================================================

std::vector<InSramOp>
TraceGenerator::generate_matmul(int iterations, KernelData* data) {

    validate_iterations(iterations);

    std::vector<InSramOp> trace;
    trace.reserve(static_cast<size_t>(iterations) * 5);

    uint64_t id = 1;

    for (int i = 0; i < iterations; ++i) {

        // O1: A1 * B1
        trace.push_back(
            make_op(
                id++,
                OpType::MUL,
                1, 2, 3,
                true, true,
                true, false
            )
        );

        // O2: A2 * B2
        trace.push_back(
            make_op(
                id++,
                OpType::MUL,
                4, 5, 6,
                true, true,
                true, false
            )
        );

        // O3: Partial sum
        // Operands are already available in wordlines.
        trace.push_back(
            make_op(
                id++,
                OpType::ADD,
                3, 6, 7,
                false, false,
                true, false
            )
        );

        // O4: Accumulate and store the output.
        trace.push_back(
            make_op(
                id++,
                OpType::ADD,
                7, 8, 8,
                false, false,
                true, true
            )
        );

        // B: Loop-control branch
        trace.push_back(
            make_op(
                id++,
                OpType::BRANCH,
                8, 0, 0,
                false, false,
                true, false,
                true
            )
        );
    }

    // ---- real data and memory addresses (thread computing C[0][0], matrix size n = iterations) ----
    {
        const uint32_t n = static_cast<uint32_t>(iterations), nn = n * n;
        const uint32_t A = 0, B = nn, C = 2 * nn;
        for (uint32_t k = 0; k < n; ++k) {
            const size_t base = static_cast<size_t>(k) * 5;
            trace[base + 0].load1_addr = A + k;          // A[0][k]
            trace[base + 0].load2_addr = B + k * n;      // B[k][0]
            trace[base + 1].load1_addr = A + k * n;      // A[k][0]
            trace[base + 1].load2_addr = B + k;          // B[0][k]
            trace[base + 3].store_addr = C;              // C[0][0] (running sum)
        }
        if (data) {
            data->name = "matmul (computes C[0][0] of an n x n product, n = iterations)";
            data->memory.assign(3 * static_cast<size_t>(nn), 0);
            for (uint32_t x = 0; x < nn; ++x) {
                data->memory[A + x] = pat(static_cast<int>(x), 7, 3, 11, 5);
                data->memory[B + x] = pat(static_cast<int>(x), 5, 1, 9, 4);
            }
            std::vector<uint32_t> a1, b1, a2, b2;
            int32_t sum = 0;
            for (uint32_t k = 0; k < n; ++k) {
                a1.push_back(A + k); b1.push_back(B + k * n); a2.push_back(A + k * n); b2.push_back(B + k);
                sum += data->memory[A + k] * data->memory[B + k * n] + data->memory[A + k * n] * data->memory[B + k];
            }
            data->input_lines = {
                "Computation: C[0][0] = sum over k of ( A[0][k]*B[k][0] + A[k][0]*B[0][k] ),  k = 0.." + std::to_string(n - 1),
                list_values(data->memory, "A[0][k]", a1), list_values(data->memory, "B[k][0]", b1),
                list_values(data->memory, "A[k][0]", a2), list_values(data->memory, "B[0][k]", b2)};
            data->expected = {{C, sum, "C[0][0]"}};
        }
    }

    return trace;
}

// ============================================================
// 2. STENCIL
// ============================================================
//
// Simplified 2D stencil operation trace.
//
// O1: Load North and South; add.
// O2: Load East and West; add.
// O3: Combine the two partial sums.
// O4: Multiply by the stencil weight and store output.
// B : Loop-control branch.
//
// Five operations per iteration.
//
// ============================================================

std::vector<InSramOp>
TraceGenerator::generate_stencil(int iterations, KernelData* data) {

    validate_iterations(iterations);

    std::vector<InSramOp> trace;
    trace.reserve(static_cast<size_t>(iterations) * 5);

    uint64_t id = 1;

    for (int i = 0; i < iterations; ++i) {

        // O1: North + South
        trace.push_back(
            make_op(
                id++,
                OpType::ADD,
                1, 2, 5,
                true, true,
                true, false
            )
        );

        // O2: East + West
        trace.push_back(
            make_op(
                id++,
                OpType::ADD,
                3, 4, 6,
                true, true,
                true, false
            )
        );

        // O3: Combine partial sums
        trace.push_back(
            make_op(
                id++,
                OpType::ADD,
                5, 6, 7,
                false, false,
                true, false
            )
        );

        // O4: Apply weight and store output
        trace.push_back(
            make_op(
                id++,
                OpType::MUL,
                7, 9, 10,
                false, false,
                true, true
            )
        );

        // B: Loop-control branch
        trace.push_back(
            make_op(
                id++,
                OpType::BRANCH,
                10, 0, 0,
                false, false,
                true, false,
                true
            )
        );
    }

    // ---- real data and memory addresses: one output point per iteration ----
    {
        const uint32_t it = static_cast<uint32_t>(iterations);
        for (uint32_t i = 0; i < it; ++i) {
            const size_t base = static_cast<size_t>(i) * 5;
            trace[base + 0].load1_addr = i;              // North[i]
            trace[base + 0].load2_addr = it + i;         // South[i]
            trace[base + 1].load1_addr = 2 * it + i;     // East[i]
            trace[base + 1].load2_addr = 3 * it + i;     // West[i]
            trace[base + 3].store_addr = 4 * it + i;     // out[i]
        }
        if (data) {
            data->name = "stencil (out[i] = weight * (N[i] + S[i] + E[i] + W[i]), one point per iteration)";
            data->memory.assign(5 * static_cast<size_t>(it), 0);
            const int mul[4] = {3, 5, 7, 11}, add[4] = {1, 2, 3, 4};
            const char* nm[4] = {"North", "South", "East ", "West "};
            data->init_reg[9] = 3;      // stencil weight lives in r9
            for (int d = 0; d < 4; ++d) {
                std::vector<uint32_t> ad;
                for (uint32_t i = 0; i < it; ++i) {
                    data->memory[d * it + i] = pat(static_cast<int>(i), mul[d], add[d], 13, 6);
                    ad.push_back(d * it + i);
                }
                data->input_lines.push_back(list_values(data->memory, nm[d], ad));
            }
            data->input_lines.insert(data->input_lines.begin(), "weight (register r9) = 3");
            for (uint32_t i = 0; i < it; ++i) {
                int32_t v = 3 * ((data->memory[i] + data->memory[it + i]) + (data->memory[2 * it + i] + data->memory[3 * it + i]));
                data->expected.push_back({4 * it + i, v, "out[" + std::to_string(i) + "]"});
            }
        }
    }

    return trace;
}

// ============================================================
// 3. K-MEANS
// ============================================================
//
// Simplified distance-accumulation operation trace.
//
// O1: Load point and centroid; subtract.
// O2: Square the difference.
// O3: Accumulate squared distance and store output.
// B : Loop-control branch.
//
// Four operations per iteration.
//
// ============================================================

std::vector<InSramOp>
TraceGenerator::generate_kmeans(int iterations, KernelData* data) {

    validate_iterations(iterations);

    std::vector<InSramOp> trace;
    trace.reserve(static_cast<size_t>(iterations) * 4);

    uint64_t id = 1;

    for (int i = 0; i < iterations; ++i) {

        // O1: Point - centroid
        trace.push_back(
            make_op(
                id++,
                OpType::SUB,
                1, 2, 3,
                true, true,
                true, false
            )
        );

        // O2: Square the difference
        trace.push_back(
            make_op(
                id++,
                OpType::MUL,
                3, 3, 4,
                false, false,
                true, false
            )
        );

        // O3: Accumulate squared distance and store
        trace.push_back(
            make_op(
                id++,
                OpType::ADD,
                4, 5, 5,
                false, false,
                true, true
            )
        );

        // B: Loop-control branch
        trace.push_back(
            make_op(
                id++,
                OpType::BRANCH,
                5, 0, 0,
                false, false,
                true, false,
                true
            )
        );
    }

    // ---- real data and memory addresses: squared distance accumulated over features ----
    {
        const uint32_t it = static_cast<uint32_t>(iterations);
        for (uint32_t f = 0; f < it; ++f) {
            const size_t base = static_cast<size_t>(f) * 4;
            trace[base + 0].load1_addr = f;              // point[f]
            trace[base + 0].load2_addr = it + f;         // centroid[f]
            trace[base + 2].store_addr = 2 * it;         // running squared distance
        }
        if (data) {
            data->name = "kmeans (squared distance between one point and one centroid, sum over features)";
            data->memory.assign(2 * static_cast<size_t>(it) + 1, 0);
            std::vector<uint32_t> pa, ca;
            int32_t acc = 0;
            for (uint32_t f = 0; f < it; ++f) {
                data->memory[f] = pat(static_cast<int>(f), 7, 3, 41, 20);
                data->memory[it + f] = pat(static_cast<int>(f), 11, 5, 31, 15);
                pa.push_back(f); ca.push_back(it + f);
                int32_t d = data->memory[f] - data->memory[it + f];
                acc += d * d;
            }
            data->input_lines = {list_values(data->memory, "point[f]   ", pa), list_values(data->memory, "centroid[f]", ca),
                                 "Computation: distance^2 = sum over f of (point[f] - centroid[f])^2"};
            data->expected = {{2 * it, acc, "distance^2"}};
        }
    }

    return trace;
}
